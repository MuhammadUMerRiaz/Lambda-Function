const sgMail = require("@sendgrid/mail");
sgMail.setApiKey('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');
var handler =async (req, res) => {
  // Checking if email already exist.
  let otp = req.body.otp;
      //Email Template for PIN CODE
      const message = {
        from: 'jackolvia444@gmail.com', // Sender address
        to: req.body.to_email, // List of recipients
        subject: `Putlocker Access Code: ${otp}`, // Subject line
        html:
          '<h1 style="font:32px/36px Helvetica,Arial,sans-serif;color:#371989;letter-spacing:0.5px;padding:0 0 36px;margin:0">Welcome!</h1>' +
          '<p style="font:16px/24px Helvetica,Arial,sans-serif;color:#757575;padding:0 0 22px;margin:0">Use the code below to login to Putlocker Photo Vault.</p>' +
          '<h4 style="font:24px/36px Arial,Helvetica,sans-serif;color:#757575;text-align:center;margin:0">Enter the code:</h4>' +
          `<h3 style="font:700 24px/36px Arial,Helvetica,sans-serif;color:#00aeef;text-transform:uppercase;text-decoration:underline;margin:0;text-align:center;padding-bottom:36px">${otp}</h3>` +
          '<p style="font:16px/24px Helvetica,Arial,sans-serif;color:#757575;padding:0 0 22px;margin:0">Didn’t request an access code? Then you can ignore this email.</p>' +
          '<p style="font:16px/24px Helvetica,Arial,sans-serif;color:#757575;padding:0 0 22px;margin:0">Your Friends, <br><strong style="color:#371989">The Putlocker Team</strong></p>',
      };
      await sgMail.send(message, function (err, info) {
        if (err) {
          console.log(err);
          res.send({
            success: false,
            reason: "SERVER_ERROR",
          });
        }
        else {
         
            res.send({
              success: true,
              user: {
                email: req.body.to_email,
                status: 200,
              },
            });
          
        }
      });
};
